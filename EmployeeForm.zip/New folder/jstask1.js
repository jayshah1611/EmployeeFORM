
        function newFunction() {
            document.getElementById("newForm").reset();
        }


        function newFunction2() {
                        document.getElementById("spouse").readOnly = true; 
                       
        }
		
		
		 function newFunction3() {

                        document.getElementById("spouse").readOnly = false;   
      
             
        }



        
  function validateForm() {



    
    var fname = document.forms["Form"]["firstname"].value;
    var lname = document.forms["Form"]["lastname"].value;
	var Sname = document.forms["Form"]["spouse"].value;
    var pat= /^([A-Za-z])+$/;

    var Result_F = pat.test(fname);
    var Result_L = pat.test(lname);
    var Result_S = pat.test(Sname);


    


   


    var a = document.forms["Form"]["firstname"].value.length;
    var b = document.forms["Form"]["lastname"].value.length;
    var c = document.forms["Form"]["spouse"].value.length;
    
    if (a == 0 || a >10 || Result_F == false) {
      alert("Please Enter Valid input..(Input should not be empty, First letter always Capital,Input Always in Character only)");
      firstname.focus();
      return false;


      
    }

    else if (b == 0 || b >10|| Result_L == false) {
      alert("Please Enter Valid input..(Input should not be empty, First letter always Capital,Input Always in Character only)");
      lastname.focus();
      return false;
    }

   else if (c == 0 || c >10 || Result_S == false) {
      alert("Please Enter Valid input..(Input should not be empty, Input Always in Character only)");
      spouse.focus();
      return false;
    }



    else{

        alert("Thank you, Data Submit");
        return true;

    }



  }







